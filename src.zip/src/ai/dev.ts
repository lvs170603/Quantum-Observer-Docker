import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-job-anomalies.ts';